-- Users table
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  openId TEXT UNIQUE NOT NULL,
  name TEXT,
  email TEXT,
  loginMethod TEXT,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  balance TEXT DEFAULT '0',
  createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
  updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
  lastSignedIn TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_openId ON users(openId);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Platforms table
CREATE TABLE IF NOT EXISTS platforms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  baseUrl TEXT NOT NULL,
  encryptedMasterCredentials TEXT NOT NULL,
  isActive TEXT DEFAULT 'active' CHECK (isActive IN ('active', 'inactive')),
  createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
  updatedAt TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_platforms_isActive ON platforms(isActive);

-- PlatformAccounts table
CREATE TABLE IF NOT EXISTS platformAccounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId INTEGER NOT NULL,
  platformId INTEGER NOT NULL,
  encryptedCredentials TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'failed', 'suspended')),
  jobId TEXT,
  createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
  updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (platformId) REFERENCES platforms(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_platformAccounts_userId ON platformAccounts(userId);
CREATE INDEX IF NOT EXISTS idx_platformAccounts_status ON platformAccounts(status);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId INTEGER NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('deposit', 'withdrawal', 'refund')),
  amount TEXT NOT NULL,
  currency TEXT DEFAULT 'BTC',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'failed', 'cancelled')),
  invoiceId TEXT,
  destination TEXT,
  transactionHash TEXT,
  errorMessage TEXT,
  jobId TEXT,
  createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
  updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_transactions_userId ON transactions(userId);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_invoiceId ON transactions(invoiceId);
CREATE INDEX IF NOT EXISTS idx_transactions_createdAt ON transactions(createdAt);

-- WithdrawalCooldowns table
CREATE TABLE IF NOT EXISTS withdrawalCooldowns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userId INTEGER UNIQUE NOT NULL,
  lastWithdrawalAt TEXT,
  cooldownUntil TEXT,
  createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
  updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_withdrawalCooldowns_cooldownUntil ON withdrawalCooldowns(cooldownUntil);

-- Jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  jobId TEXT UNIQUE NOT NULL,
  type TEXT NOT NULL,
  userId INTEGER,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  retryCount INTEGER DEFAULT 0,
  maxRetries INTEGER DEFAULT 3,
  data TEXT,
  errorMessage TEXT,
  createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
  updatedAt TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_type ON jobs(type);
CREATE INDEX IF NOT EXISTS idx_jobs_createdAt ON jobs(createdAt);