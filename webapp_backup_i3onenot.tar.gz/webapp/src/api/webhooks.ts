import { Hono } from 'hono'
import crypto from 'crypto'

const router = new Hono()

// BTCPay Server webhook handler
router.post('/btcpay', async (c) => {
  const body = await c.req.text()
  const signature = c.req.header('BTCPay-Sig')
  
  if (!signature) {
    return c.json({
      success: false,
      error: 'Missing BTCPay signature'
    }, 401)
  }
  
  // Verify webhook signature
  const expectedSignature = 'sha256=' + crypto
    .createHmac('sha256', process.env.BTCPAY_WEBHOOK_SECRET || 'webhook-secret')
    .update(body)
    .digest('hex')
  
  if (signature !== expectedSignature) {
    return c.json({
      success: false,
      error: 'Invalid webhook signature'
    }, 401)
  }
  
  const webhookData = JSON.parse(body)
  
  // Process webhook based on event type
  switch (webhookData.type) {
    case 'InvoiceCreated':
      console.log('Invoice created:', webhookData.data.id)
      break
    
    case 'InvoiceReceivedPayment':
      console.log('Payment received for invoice:', webhookData.data.id)
      break
    
    case 'InvoiceProcessing':
      console.log('Invoice processing:', webhookData.data.id)
      break
    
    case 'InvoiceExpired':
      console.log('Invoice expired:', webhookData.data.id)
      break
    
    case 'InvoiceSettled':
      console.log('Invoice settled:', webhookData.data.id)
      break
    
    case 'InvoiceInvalid':
      console.log('Invoice invalid:', webhookData.data.id)
      break
    
    default:
      console.log('Unknown webhook type:', webhookData.type)
  }
  
  return c.json({
    success: true,
    message: 'Webhook processed'
  })
})

// General webhook endpoint for other services
router.post('/generic', async (c) => {
  const body = await c.req.text()
  const signature = c.req.header('X-Webhook-Signature')
  
  if (!signature) {
    return c.json({
      success: false,
      error: 'Missing webhook signature'
    }, 401)
  }
  
  // Verify signature (mock implementation)
  const expectedSignature = crypto
    .createHmac('sha256', process.env.WEBHOOK_SECRET || 'webhook-secret')
    .update(body)
    .digest('hex')
  
  if (signature !== expectedSignature) {
    return c.json({
      success: false,
      error: 'Invalid webhook signature'
    }, 401)
  }
  
  const webhookData = JSON.parse(body)
  
  // Process generic webhook
  console.log('Generic webhook received:', webhookData)
  
  return c.json({
    success: true,
    message: 'Webhook processed'
  })
})

// Health check endpoint for webhook status
router.get('/health', async (c) => {
  return c.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString()
  })
})

export { router as webhookRouter }