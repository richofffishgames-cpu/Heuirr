import { Hono } from 'hono'
import { z } from 'zod'
import { zValidator } from '@hono/zod-validator'

const redeemSchema = z.object({
  userId: z.number().int().positive(),
  amount: z.string().regex(/^\d+\.?\d*$/),
  destination: z.string().min(26).max(100),
  currency: z.enum(['BTC', 'ETH']).default('BTC')
})

const router = new Hono()

router.post('/request',
  zValidator('json', redeemSchema),
  async (c) => {
    const { userId, amount, destination, currency } = c.req.valid('json')
    
    // Mock redemption request
    const redeemId = `redeem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    return c.json({
      success: true,
      data: {
        redeemId,
        amount,
        destination,
        currency,
        status: 'pending',
        estimatedProcessingTime: '1-2 business days',
        createdAt: new Date().toISOString()
      }
    }, 201)
  }
)

router.get('/status/:redeemId', async (c) => {
  const redeemId = c.req.param('redeemId')
  
  // Mock redemption status
  return c.json({
    success: true,
    data: {
      redeemId,
      status: 'completed',
      txId: 'tx1234567890abcdef',
      amount: '0.001',
      currency: 'BTC',
      completedAt: new Date(Date.now() - 3600000).toISOString()
    }
  })
})

export { router as redeemRouter }