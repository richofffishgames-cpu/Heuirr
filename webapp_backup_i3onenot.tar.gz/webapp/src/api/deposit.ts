import { Hono } from 'hono'
import { z } from 'zod'
import { zValidator } from '@hono/zod-validator'

const depositSchema = z.object({
  userId: z.number().int().positive(),
  amount: z.string().regex(/^\d+\.?\d*$/),
  currency: z.enum(['BTC', 'ETH']).default('BTC'),
  type: z.enum(['invoice', 'address']).default('invoice')
})

const router = new Hono()

router.post('/initiate',
  zValidator('json', depositSchema),
  async (c) => {
    const { userId, amount, currency, type } = c.req.valid('json')
    
    // Mock deposit initiation
    const invoiceId = `inv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const address = `bc1q${Math.random().toString(36).substr(2, 38)}`
    
    return c.json({
      success: true,
      data: {
        invoiceId,
        address,
        amount,
        currency,
        status: 'pending',
        expiresAt: new Date(Date.now() + 3600000).toISOString() // 1 hour
      }
    }, 201)
  }
)

router.get('/history/:userId', async (c) => {
  const userId = c.req.param('userId')
  
  // Mock deposit history
  const deposits = [
    {
      id: 1,
      invoiceId: 'inv_1234567890',
      address: 'bc1qtestaddress1234567890',
      amount: '0.001',
      currency: 'BTC',
      status: 'confirmed',
      createdAt: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: 2,
      invoiceId: 'inv_0987654321',
      address: 'bc1qtestaddress0987654321',
      amount: '0.005',
      currency: 'BTC',
      status: 'pending',
      createdAt: new Date(Date.now() - 3600000).toISOString()
    }
  ]
  
  return c.json({
    success: true,
    data: deposits
  })
})

router.get('/status/:invoiceId', async (c) => {
  const invoiceId = c.req.param('invoiceId')
  
  // Mock status check
  return c.json({
    success: true,
    data: {
      invoiceId,
      status: 'confirmed',
      amount: '0.001',
      currency: 'BTC',
      confirmations: 3,
      txId: 'tx1234567890abcdef'
    }
  })
})

export { router as depositRouter }