import { Hono } from 'hono'
import { z } from 'zod'
import { zValidator } from '@hono/zod-validator'
import { JWTService } from '../services/jwt'
import type { CloudflareBindings } from '../types'

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
})

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(2)
})

// Create router with proper typing
const router = new Hono<{ Bindings: CloudflareBindings }>()

/**
 * Login endpoint
 */
router.post('/login',
  zValidator('json', loginSchema),
  async (c) => {
    const { email, password } = c.req.valid('json')
    
    try {
      const jwtService = new JWTService(c.env)
      const user = await jwtService.authenticateUser(email, password)
      
      if (!user) {
        return c.json({
          success: false,
          error: 'Invalid credentials'
        }, 401)
      }
      
      const token = jwtService.generateToken(user)
      
      return c.json({
        success: true,
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          balance: user.balance
        }
      })
    } catch (error) {
      console.error('Login error:', error)
      return c.json({
        success: false,
        error: 'Authentication failed'
      }, 500)
    }
  }
)

/**
 * Registration endpoint
 */
router.post('/register',
  zValidator('json', registerSchema),
  async (c) => {
    const { email, password, name } = c.req.valid('json')
    
    try {
      const jwtService = new JWTService(c.env)
      
      // Check if user already exists
      const existingUser = await c.env.DB.prepare(
        'SELECT id FROM users WHERE email = ?'
      ).bind(email).first()
      
      if (existingUser) {
        return c.json({
          success: false,
          error: 'Email already registered'
        }, 400)
      }
      
      const user = await jwtService.createUser(email, password, name)
      const token = jwtService.generateToken(user)
      
      return c.json({
        success: true,
        message: 'User registered successfully',
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          balance: user.balance
        }
      }, 201)
    } catch (error) {
      console.error('Registration error:', error)
      return c.json({
        success: false,
        error: 'Registration failed'
      }, 500)
    }
  }
)

/**
 * Get current user profile
 * Requires authentication
 */
router.get('/me', 
  async (c) => {
    try {
      const authHeader = c.req.header('Authorization')
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return c.json({
          success: false,
          error: 'No token provided'
        }, 401)
      }
      
      const token = authHeader.substring(7)
      const jwtService = new JWTService(c.env)
      const payload = jwtService.verifyToken(token)
      const user = await jwtService.getUserById(payload.userId)
      
      if (!user) {
        return c.json({
          success: false,
          error: 'User not found'
        }, 404)
      }
      
      return c.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          balance: user.balance
        }
      })
    } catch (error) {
      console.error('Get profile error:', error)
      const message = error instanceof Error ? error.message : 'Authentication failed'
      return c.json({
        success: false,
        error: message
      }, 401)
    }
  }
)

/**
 * Logout endpoint
 * (In a real implementation, you might want to blacklist the token)
 */
router.post('/logout', async (c) => {
  return c.json({
    success: true,
    message: 'Logged out successfully'
  })
})

export { router as authRouter }