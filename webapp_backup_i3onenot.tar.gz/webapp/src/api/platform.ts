import { Hono } from 'hono'
import { z } from 'zod'
import { zValidator } from '@hono/zod-validator'

const platformSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  masterUsername: z.string().min(3),
  masterPassword: z.string().min(6),
  baseUrl: z.string().url()
})

const accountRequestSchema = z.object({
  userId: z.number().int().positive(),
  platformId: z.number().int().positive()
})

const router = new Hono()

router.get('/list', async (c) => {
  // Mock platform list
  const platforms = [
    {
      id: 1,
      name: 'Steam',
      description: 'Popular gaming platform',
      baseUrl: 'https://store.steampowered.com',
      isActive: true
    },
    {
      id: 2,
      name: 'Epic Games',
      description: 'Epic Games Store',
      baseUrl: 'https://store.epicgames.com',
      isActive: true
    },
    {
      id: 3,
      name: 'GOG',
      description: 'Good Old Games',
      baseUrl: 'https://www.gog.com',
      isActive: false
    }
  ]
  
  return c.json({
    success: true,
    data: platforms
  })
})

router.post('/create',
  zValidator('json', platformSchema),
  async (c) => {
    const platformData = c.req.valid('json')
    
    // Mock platform creation
    const newPlatform = {
      id: Math.floor(Math.random() * 1000),
      ...platformData,
      isActive: true,
      createdAt: new Date().toISOString()
    }
    
    return c.json({
      success: true,
      data: newPlatform
    }, 201)
  }
)

router.post('/getAccount',
  zValidator('json', accountRequestSchema),
  async (c) => {
    const { userId, platformId } = c.req.valid('json')
    
    // Mock account provisioning
    const username = `user_${userId}_${platformId}`
    const password = Math.random().toString(36).slice(-10)
    
    return c.json({
      success: true,
      data: {
        platformId,
        userId,
        username,
        password,
        status: 'assigned',
        createdAt: new Date().toISOString()
      }
    }, 201)
  }
)

router.get('/myAccounts/:userId', async (c) => {
  const userId = c.req.param('userId')
  
  // Mock user accounts
  const accounts = [
    {
      id: 1,
      platformId: 1,
      username: 'user_123_1',
      status: 'assigned',
      createdAt: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: 2,
      platformId: 2,
      username: 'user_123_2',
      status: 'assigned',
      createdAt: new Date(Date.now() - 172800000).toISOString()
    }
  ]
  
  return c.json({
    success: true,
    data: accounts
  })
})

export { router as platformRouter }