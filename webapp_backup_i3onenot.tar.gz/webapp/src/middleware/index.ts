import { Context, Next } from 'hono'
import { cors } from 'hono/cors'
import { logger } from 'hono/logger'
import { z } from 'zod'
import { JWTService } from '../services/jwt'

// Environment variables
const NODE_ENV = process.env.NODE_ENV || 'development'

// Rate limiting storage (in production, use Redis)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

// Rate limiting configuration
const RATE_LIMITS = {
  api: { windowMs: 60 * 1000, max: 100 }, // 100 requests per minute
  auth: { windowMs: 60 * 1000, max: 10 }, // 10 requests per minute for auth
  withdrawal: { windowMs: 60 * 60 * 1000, max: 5 }, // 5 withdrawals per hour
}

// CORS configuration
export const corsMiddleware = cors({
  origin: NODE_ENV === 'production' 
    ? ['https://your-domain.com'] 
    : ['http://localhost:3000', 'http://localhost:5173'],
  credentials: true,
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
})

// Logger middleware
export const loggingMiddleware = logger()

// Security headers middleware
export const securityHeaders = async (c: Context, next: Next) => {
  await next()
  
  c.header('X-Content-Type-Options', 'nosniff')
  c.header('X-Frame-Options', 'DENY')
  c.header('X-XSS-Protection', '1; mode=block')
  c.header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
  c.header('Referrer-Policy', 'strict-origin-when-cross-origin')
  
  if (NODE_ENV === 'production') {
    c.header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com")
  }
}

// Rate limiting middleware
export const rateLimit = (type: 'api' | 'auth' | 'withdrawal') => {
  return async (c: Context, next: Next) => {
    const ip = c.req.header('x-forwarded-for') || c.req.header('x-real-ip') || 'unknown'
    const key = `${type}:${ip}`
    const now = Date.now()
    const limit = RATE_LIMITS[type]
    
    // Clean up old entries
    for (const [k, v] of rateLimitStore.entries()) {
      if (v.resetTime < now) {
        rateLimitStore.delete(k)
      }
    }
    
    // Get current data
    const current = rateLimitStore.get(key)
    
    if (!current) {
      rateLimitStore.set(key, {
        count: 1,
        resetTime: now + limit.windowMs
      })
    } else {
      if (current.resetTime < now) {
        // Reset counter
        current.count = 1
        current.resetTime = now + limit.windowMs
      } else if (current.count >= limit.max) {
        // Rate limit exceeded
        c.status(429)
        return c.json({ 
          error: 'Too many requests',
          retryAfter: Math.ceil((current.resetTime - now) / 1000)
        })
      } else {
        current.count++
      }
    }
    
    await next()
  }
}

// Authentication middleware
export const authMiddleware = async (c: Context, next: Next) => {
  const authHeader = c.req.header('Authorization')
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    c.status(401)
    return c.json({ error: 'No token provided' })
  }
  
  const token = authHeader.substring(7)
  
  try {
    const jwtService = new JWTService(c.env)
    const payload = jwtService.verifyToken(token)
    
    // Store user info in context
    c.set('userId', payload.userId)
    c.set('userRole', payload.role)
    
    await next()
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Invalid token'
    c.status(401)
    return c.json({ error: message })
  }
}

// Admin middleware
export const adminMiddleware = async (c: Context, next: Next) => {
  const userRole = c.get('userRole')
  
  if (userRole !== 'admin') {
    c.status(403)
    return c.json({ error: 'Admin access required' })
  }
  
  await next()
}

// Validation middleware
export const validate = (schema: z.ZodSchema) => {
  return async (c: Context, next: Next) => {
    try {
      const body = await c.req.json()
      const validated = schema.parse(body)
      c.set('validated', validated)
      await next()
    } catch (error) {
      if (error instanceof z.ZodError) {
        c.status(400)
        return c.json({ 
          error: 'Validation failed',
          details: error.errors 
        })
      }
      throw error
    }
  }
}

// Error handling middleware
export const errorHandler = async (c: Context, next: Next) => {
  try {
    await next()
  } catch (error) {
    console.error('Error:', error)
    
    if (error instanceof Error) {
      c.status(500)
      return c.json({ 
        error: 'Internal server error',
        message: NODE_ENV === 'development' ? error.message : undefined
      })
    }
    
    c.status(500)
    return c.json({ error: 'Internal server error' })
  }
}

// Request ID middleware
export const requestId = async (c: Context, next: Next) => {
  const requestId = c.req.header('X-Request-ID') || crypto.randomUUID()
  c.set('requestId', requestId)
  c.header('X-Request-ID', requestId)
  await next()
}

// Logging middleware with structured data
export const structuredLogger = (message: string, data?: any) => {
  const logData = {
    timestamp: new Date().toISOString(),
    level: 'info',
    message,
    ...(data && { data })
  }
  
  console.log(JSON.stringify(logData))
}

// Webhook signature verification middleware
export const verifyWebhookSignature = (secret: string) => {
  return async (c: Context, next: Next) => {
    const signature = c.req.header('X-Signature')
    const body = await c.req.text()
    
    if (!signature) {
      c.status(401)
      return c.json({ error: 'No signature provided' })
    }
    
    const crypto = require('../crypto')
    if (!crypto.verifyHmacSignature(body, signature, secret)) {
      c.status(401)
      return c.json({ error: 'Invalid signature' })
    }
    
    await next()
  }
}

// Timeout middleware
export const timeout = (ms: number) => {
  return async (c: Context, next: Next) => {
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout')), ms)
    })
    
    try {
      await Promise.race([next(), timeoutPromise])
    } catch (error) {
      if (error instanceof Error && error.message === 'Request timeout') {
        c.status(408)
        return c.json({ error: 'Request timeout' })
      }
      throw error
    }
  }
}

// Cache control middleware
export const cacheControl = (maxAge: number) => {
  return async (c: Context, next: Next) => {
    await next()
    c.header('Cache-Control', `max-age=${maxAge}`)
  }
}