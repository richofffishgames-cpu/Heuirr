import type { Platform, Job } from '../types'

/**
 * Convert satoshis to BTC
 */
export function satoshisToBtc(satoshis: number): number {
  return satoshis / 100000000;
}

/**
 * Convert BTC to satoshis
 */
export function btcToSatoshis(btc: number): number {
  return Math.round(btc * 100000000);
}

/**
 * Generate a secure random string
 */
export function generateSecureRandom(length: number): string {
  const crypto = require('crypto');
  return crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
}

/**
 * Validate Bitcoin address
 */
export function validateBitcoinAddress(address: string): boolean {
  // Basic validation - could be enhanced with more sophisticated checks
  return /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(address) || /^bc1[a-z0-9]{39,59}$/.test(address);
}

/**
 * Create a new platform in the database
 */
export async function createPlatform(
  db: D1Database,
  name: string,
  baseUrl: string,
  encryptedMasterCredentials: string
): Promise<Platform> {
  const stmt = db.prepare(`
    INSERT INTO platforms (name, baseUrl, encryptedMasterCredentials)
    VALUES (?, ?, ?)
    RETURNING *
  `)
  const result = await stmt.bind(name, baseUrl, encryptedMasterCredentials).first<Platform>()
  if (!result) throw new Error('Failed to create platform')
  return result
}

/**
 * Helper function to create a job in the database
 */
export async function createJob(
  db: D1Database,
  jobId: string,
  type: string,
  userId?: number,
  data?: Record<string, any>
): Promise<Job> {
  const stmt = db.prepare(`
    INSERT INTO jobs (jobId, type, userId, data)
    VALUES (?, ?, ?, ?)
    RETURNING *
  `)
  const dataJson = data ? JSON.stringify(data) : null
  const result = await stmt.bind(jobId, type, userId, dataJson).first<Job>()
  if (!result) throw new Error('Failed to create job')
  return result
}

/**
 * Format cryptocurrency amount with proper decimal places
 */
export function formatCryptoAmount(amount: string | number, currency: string = 'BTC'): string {
  const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount
  const decimals = currency === 'BTC' ? 8 : 18 // BTC: 8 decimals, ETH: 18 decimals
  return numAmount.toFixed(decimals)
}

/**
 * Validate cryptocurrency address
 */
export function isValidCryptoAddress(address: string, currency: string = 'BTC'): boolean {
  // Basic validation - in production, use proper validation libraries
  if (currency === 'BTC') {
    // Bitcoin address validation
    return /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(address) || 
           /^bc1[a-z0-9]{39,59}$/.test(address)
  } else if (currency === 'ETH') {
    // Ethereum address validation
    return /^0x[a-fA-F0-9]{40}$/.test(address)
  }
  return false
}

/**
 * Calculate withdrawal cooldown time
 */
export function calculateCooldownTime(amount: number): Date {
  const now = new Date()
  // 24 hours for amounts > 0.012 BTC
  if (amount > 0.012) {
    return new Date(now.getTime() + 24 * 60 * 60 * 1000)
  }
  return now // No cooldown for smaller amounts
}

/**
 * Generate a unique job ID
 */
export function generateJobId(type: string, userId: number): string {
  return `${type}_${userId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

/**
 * Sanitize error message for client response
 */
export function sanitizeErrorMessage(error: any): string {
  if (error instanceof Error) {
    // Remove sensitive information from error messages
    return error.message.replace(/\(.*?\)/g, '').trim()
  }
  return 'An unexpected error occurred'
}

/**
 * Parse database timestamp to Date object
 */
export function parseDbTimestamp(timestamp: string | null): Date | null {
  if (!timestamp) return null
  return new Date(timestamp)
}

/**
 * Format date for display
 */
export function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleString()
}

/**
 * Calculate percentage change
 */
export function calculatePercentageChange(oldValue: number, newValue: number): number {
  if (oldValue === 0) return newValue > 0 ? 100 : 0
  return ((newValue - oldValue) / oldValue) * 100
}

/**
 * Sleep/delay function
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/**
 * Retry function with exponential backoff
 */
export async function retry<T>(
  fn: () => Promise<T>,
  retries = 3,
  delay = 1000
): Promise<T> {
  let lastError: Error
  
  for (let i = 0; i < retries; i++) {
    try {
      return await fn()
    } catch (error) {
      lastError = error as Error
      if (i < retries - 1) {
        await sleep(delay * Math.pow(2, i))
      }
    }
  }
  
  throw lastError!
}

/**
 * Generate a random string
 */
export function randomString(length: number): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let result = ''
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

/**
 * Deep clone an object
 */
export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj))
}