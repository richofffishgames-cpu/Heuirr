import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { logger } from 'hono/logger'
import { serveStatic } from 'hono/cloudflare-workers'
import type { CloudflareBindings } from './types'
import { securityHeaders, errorHandler, requestId } from './middleware'

// Import API routes
import { authRouter } from './api/auth'
import { depositRouter } from './api/deposit'
import { platformRouter } from './api/platform'
import { redeemRouter } from './api/redeem'
import { adminRouter } from './api/admin'
import { webhookRouter } from './api/webhooks'
import { createSigningRouter } from './api/signing'
import { createUtxoRouter } from './api/utxo'
import { createConsolidationRouter } from './api/consolidation'
import { createReconciliationRouter } from './api/reconciliation'
import { createObservabilityRouter } from './api/observability'
import { createFeeRouter } from './api/fee'
import { createChangePolicyRouter } from './api/change-policies'

const app = new Hono<{ Bindings: CloudflareBindings }>()

// Global middleware
app.use('*', logger())
app.use('*', requestId)
app.use('*', securityHeaders)
app.use('*', cors({
  origin: (origin, c) => {
    const allowedOrigins = c.env.FRONTEND_URL ? [c.env.FRONTEND_URL] : ['http://localhost:3000']
    return allowedOrigins.includes(origin) ? origin : allowedOrigins[0]
  },
  credentials: true
}))

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// Health check endpoint
app.get('/health', (c) => {
  return c.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  })
})

// API routes
app.route('/api/auth', authRouter)
app.route('/api/deposit', depositRouter)
app.route('/api/platform', platformRouter)
app.route('/api/redeem', redeemRouter)
app.route('/api/admin', adminRouter)
app.route('/api/webhooks', webhookRouter)

// Signing routes (basic version)
const signingRouter = createSigningRouter()
app.route('/api/signing', signingRouter)

// UTXO Management routes
const utxoRouter = createUtxoRouter()
app.route('/api/utxo', utxoRouter)

// Consolidation routes
const consolidationRouter = createConsolidationRouter()
app.route('/api/consolidation', consolidationRouter)

// Reconciliation routes
const reconciliationRouter = createReconciliationRouter()
app.route('/api/reconciliation', reconciliationRouter)

// Observability routes
const observabilityRouter = createObservabilityRouter()
app.route('/api/observability', observabilityRouter)

// Fee optimization routes
const feeRouter = createFeeRouter()
app.route('/api/fee', feeRouter)

// Change policy routes
const changePolicyRouter = createChangePolicyRouter()
app.route('/api/change-policy', changePolicyRouter)

// Main application route
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Crypto Platform Manager</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="/static/style.css" rel="stylesheet">
    </head>
    <body class="bg-gray-100 p-8">
        <div class="max-w-4xl mx-auto">
            <h1 class="text-3xl font-bold text-gray-800 mb-6">
                <i class="fas fa-rocket mr-2"></i>
                Crypto Platform Manager
            </h1>
            <div id="app">
                <!-- Your content here -->
            </div>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

// Global error handler
app.onError(errorHandler)

export default app