/**
 * Create a new platform in the database
 */
export async function createPlatform(
  db: D1Database,
  name: string,
  baseUrl: string,
  encryptedMasterCredentials: string
): Promise<any> {
  const stmt = db.prepare(`
    INSERT INTO platforms (name, baseUrl, encryptedMasterCredentials)
    VALUES (?, ?, ?)
    RETURNING *
  `)
  const result = await stmt.bind(name, baseUrl, encryptedMasterCredentials).first()
  if (!result) throw new Error('Failed to create platform')
  return result
}