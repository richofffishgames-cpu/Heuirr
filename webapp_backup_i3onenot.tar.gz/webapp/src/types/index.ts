export interface User {
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  loginMethod: string | null;
  role: 'user' | 'admin';
  balance: string;
  createdAt: Date;
  updatedAt: Date;
  lastSignedIn: Date;
}

export interface Platform {
  id: number;
  name: string;
  baseUrl: string;
  encryptedMasterCredentials: string;
  isActive: 'active' | 'inactive';
  createdAt: Date;
  updatedAt: Date;
}

export interface PlatformAccount {
  id: number;
  userId: number;
  platformId: number;
  encryptedCredentials: string;
  status: 'pending' | 'active' | 'failed' | 'suspended';
  jobId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Transaction {
  id: number;
  userId: number;
  type: 'deposit' | 'withdrawal' | 'refund';
  amount: string;
  currency: string;
  status: 'pending' | 'confirmed' | 'failed' | 'cancelled';
  invoiceId: string | null;
  destination: string | null;
  transactionHash: string | null;
  errorMessage: string | null;
  jobId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface WithdrawalCooldown {
  id: number;
  userId: number;
  lastWithdrawalAt: Date | null;
  cooldownUntil: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Job {
  id: number;
  jobId: string;
  type: string;
  userId: number | null;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  retryCount: number;
  maxRetries: number;
  data: Record<string, any> | null;
  errorMessage: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface BTCPayInvoice {
  id: string;
  url: string;
  checkoutLink: string;
  cryptoInfo: Array<{
    cryptoCode: string;
    address: string;
    due: string;
  }>;
}

export interface BTCPayWebhookPayload {
  invoiceId: string;
  status: 'paid' | 'confirmed' | 'invalid' | 'expired';
  amount: string;
  cryptoCode: string;
  cryptoAmount: string;
  cryptoHash: string;
  cryptoConfirmations: number;
}

export interface JobData {
  deposit: {
    userId: number;
    transactionId: number;
    amount: string;
  };
  getAccount: {
    userId: number;
    platformId: number;
    platformAccountId: number;
  };
  redeem: {
    userId: number;
    transactionId: number;
    amount: string;
    walletAddress: string;
  };
}

export type JobType = keyof JobData;

export interface JWTPayload {
  sub: string;
  iat: number;
  exp: number;
}

export interface TRPCContext {
  user?: User;
  env: CloudflareBindings;
}

export interface CloudflareBindings {
  DB: D1Database;
  CACHE: KVNamespace;
  STORAGE: R2Bucket;
  ENCRYPTION_KEY: string;
  JWT_SECRET: string;
  BTCPAY_URL: string;
  BTCPAY_API_KEY: string;
  BTCPAY_STORE_ID: string;
  BTCPAY_WEBHOOK_SECRET: string;
  FRONTEND_URL: string;
}