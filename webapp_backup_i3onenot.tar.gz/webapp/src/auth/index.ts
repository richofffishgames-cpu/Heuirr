import { SignJWT, jwtVerify } from 'jose';
import type { JWTPayload, User } from '../types';

/**
 * Generate JWT token for user authentication
 */
export async function generateJWT(user: User, secret: string): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const payload: JWTPayload = {
    sub: user.openId,
    iat: now,
    exp: now + 86400, // 24 hours
  };

  return await new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('24h')
    .sign(new TextEncoder().encode(secret));
}

/**
 * Verify and decode JWT token
 */
export async function verifyJWT(token: string, secret: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(secret));
    return payload as JWTPayload;
  } catch (error) {
    return null;
  }
}

/**
 * Extract JWT token from Authorization header or cookie
 */
export function extractJWTFromRequest(request: Request): string | null {
  // Check Authorization header
  const authHeader = request.headers.get('Authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7);
  }

  // Check cookie
  const cookie = request.headers.get('Cookie');
  if (cookie) {
    const match = cookie.match(/session=([^;]+)/);
    if (match) {
      return match[1];
    }
  }

  return null;
}

/**
 * Set JWT cookie in response
 */
export function setJWTCookie(response: Response, token: string): Response {
  const newResponse = new Response(response.body, response);
  
  // Add Set-Cookie header
  newResponse.headers.append(
    'Set-Cookie',
    `session=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=86400`
  );
  
  return newResponse;
}

/**
 * Clear JWT cookie
 */
export function clearJWTCookie(response: Response): Response {
  const newResponse = new Response(response.body, response);
  
  // Clear cookie by setting expired date
  newResponse.headers.append(
    'Set-Cookie',
    'session=; Path=/; HttpOnly; Secure; SameSite=Strict; Expires=Thu, 01 Jan 1970 00:00:00 GMT'
  );
  
  return newResponse;
}

/**
 * Generate secure random string for OAuth state
 */
export function generateOAuthState(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Generate PKCE code verifier
 */
export function generateCodeVerifier(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return btoa(String.fromCharCode(...array))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

/**
 * Generate PKCE code challenge
 */
export function generateCodeChallenge(verifier: string): string {
  const encoder = new TextEncoder();
  const data = encoder.encode(verifier);
  const hash = crypto.subtle.digest('SHA-256', data);
  
  return btoa(String.fromCharCode(...new Uint8Array(hash)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

/**
 * Validate OAuth redirect URI
 */
export function isValidRedirectUri(uri: string): boolean {
  try {
    const url = new URL(uri);
    return url.protocol === 'https:' || url.hostname === 'localhost';
  } catch {
    return false;
  }
}