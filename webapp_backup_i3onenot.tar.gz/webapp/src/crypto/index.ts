import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const TAG_LENGTH = 16;
const SALT_LENGTH = 32;
const KEY_LENGTH = 32;
const PBKDF2_ITERATIONS = 100000;

export interface EncryptedData {
  encrypted: string;
  iv: string;
  tag: string;
  salt: string;
}

/**
 * Derive encryption key from password using PBKDF2
 */
export const deriveKey = (password: string, salt: Buffer): Buffer => {
  return crypto.pbkdf2Sync(password, salt, PBKDF2_ITERATIONS, KEY_LENGTH, 'sha256');
};

/**
 * Encrypt data using AES-256-GCM
 */
export const encrypt = (data: string, password: string): EncryptedData => {
  // Generate random salt and IV
  const salt = crypto.randomBytes(SALT_LENGTH);
  const iv = crypto.randomBytes(IV_LENGTH);
  
  // Derive key from password
  const key = deriveKey(password, salt);
  
  // Create cipher
  const cipher = crypto.createCipher(ALGORITHM, key);
  cipher.setAAD(Buffer.from('crypto-platform', 'utf8'));
  
  // Encrypt data
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  // Get auth tag
  const tag = cipher.getAuthTag();
  
  return {
    encrypted,
    iv: iv.toString('hex'),
    tag: tag.toString('hex'),
    salt: salt.toString('hex')
  };
};

/**
 * Decrypt data using AES-256-GCM
 */
export const decrypt = (encryptedData: EncryptedData, password: string): string => {
  try {
    // Convert hex strings back to buffers
    const salt = Buffer.from(encryptedData.salt, 'hex');
    const iv = Buffer.from(encryptedData.iv, 'hex');
    const tag = Buffer.from(encryptedData.tag, 'hex');
    const encrypted = encryptedData.encrypted;
    
    // Derive key from password
    const key = deriveKey(password, salt);
    
    // Create decipher
    const decipher = crypto.createDecipher(ALGORITHM, key);
    decipher.setAAD(Buffer.from('crypto-platform', 'utf8'));
    decipher.setAuthTag(tag);
    
    // Decrypt data
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    throw new Error('Decryption failed: Invalid password or corrupted data');
  }
};

/**
 * Generate a secure random string
 */
export const generateSecureRandom = (length: number): string => {
  return crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
};

/**
 * Hash password using bcrypt
 */
export const hashPassword = async (password: string): Promise<string> => {
  const bcrypt = await import('bcryptjs');
  const saltRounds = 12;
  return bcrypt.hash(password, saltRounds);
};

/**
 * Verify password
 */
export const verifyPassword = async (password: string, hashedPassword: string): Promise<boolean> => {
  const bcrypt = await import('bcryptjs');
  return bcrypt.compare(password, hashedPassword);
};

/**
 * Generate JWT token
 */
export const generateToken = (payload: any, secret: string, expiresIn = '24h'): string => {
  const jwt = require('jsonwebtoken');
  return jwt.sign(payload, secret, { expiresIn });
};

/**
 * Verify JWT token
 */
export const verifyToken = (token: string, secret: string): any => {
  const jwt = require('jsonwebtoken');
  return jwt.verify(token, secret);
};

/**
 * Create HMAC signature for webhook verification
 */
export const createHmacSignature = (payload: string, secret: string): string => {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
};

/**
 * Verify HMAC signature
 */
export const verifyHmacSignature = (payload: string, signature: string, secret: string): boolean => {
  const expectedSignature = createHmacSignature(payload, secret);
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature));
};

/**
 * Convert satoshis to BTC
 */
export const satoshisToBtc = (satoshis: number): number => {
  return satoshis / 100000000;
};

/**
 * Convert BTC to satoshis
 */
export const btcToSatoshis = (btc: number): number => {
  return Math.round(btc * 100000000);
};

/**
 * Format BTC amount
 */
export const formatBtc = (amount: number): string => {
  return amount.toFixed(8);
};

/**
 * Validate Bitcoin address
 */
export const validateBitcoinAddress = (address: string): boolean => {
  // Basic validation - could be enhanced with more sophisticated checks
  return /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(address) || /^bc1[a-z0-9]{39,59}$/.test(address);
};

/**
 * Generate invoice ID
 */
export const generateInvoiceId = (): string => {
  return `inv_${Date.now()}_${generateSecureRandom(8)}`;
};

/**
 * Generate transaction ID
 */
export const generateTxId = (): string => {
  return `tx_${Date.now()}_${generateSecureRandom(8)}`;
};

/**
 * Sleep utility
 */
export const sleep = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Retry utility with exponential backoff
 */
export const retryWithBackoff = async <T>(
  fn: () => Promise<T>,
  maxAttempts = 3,
  baseDelay = 1000
): Promise<T> => {
  let lastError: Error;
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      
      if (attempt === maxAttempts) {
        throw lastError;
      }
      
      const delay = baseDelay * Math.pow(2, attempt - 1);
      await sleep(delay);
    }
  }
  
  throw lastError!;
};