// Crypto Platform Manager - Frontend Application
class CryptoPlatformManager {
  constructor() {
    this.apiBase = '/api'
    this.user = null
    this.platforms = []
    this.transactions = []
    this.init()
  }

  init() {
    this.bindEvents()
    this.checkAuth()
    this.loadPlatforms()
    this.loadTransactionHistory()
  }

  bindEvents() {
    // Auth
    document.getElementById('loginBtn').addEventListener('click', () => this.login())
    document.getElementById('logoutBtn').addEventListener('click', () => this.logout())

    // Deposit
    document.getElementById('depositBtn').addEventListener('click', () => this.showDepositModal())
    document.getElementById('cancelDeposit').addEventListener('click', () => this.hideDepositModal())
    document.getElementById('depositForm').addEventListener('submit', (e) => this.handleDeposit(e))

    // Redeem
    document.getElementById('redeemBtn').addEventListener('click', () => this.showRedeemModal())
    document.getElementById('cancelRedeem').addEventListener('click', () => this.hideRedeemModal())
    document.getElementById('redeemForm').addEventListener('submit', (e) => this.handleRedeem(e))

    // Platform
    document.getElementById('platformBtn').addEventListener('click', () => this.showPlatformModal())
    document.getElementById('cancelPlatform').addEventListener('click', () => this.hidePlatformModal())
    document.getElementById('platformForm').addEventListener('submit', (e) => this.handlePlatformRequest(e))

    // Refresh
    document.getElementById('refreshBtn').addEventListener('click', () => this.refreshData())
  }

  async checkAuth() {
    try {
      const response = await this.apiRequest('/auth/me', 'GET')
      if (response.user) {
        this.setUser(response.user)
      }
    } catch (error) {
      console.error('Auth check failed:', error)
    }
  }

  async login() {
    // Mock login - in real app, implement proper OAuth flow
    const mockUser = {
      openId: 'test_user_' + Date.now(),
      name: 'Test User',
      email: 'test@example.com',
      role: 'user'
    }

    try {
      const response = await this.apiRequest('/auth/login', 'POST', mockUser)
      if (response.success) {
        this.setUser(response.user)
        this.showNotification('Login successful!', 'success')
      }
    } catch (error) {
      this.showNotification('Login failed: ' + error.message, 'error')
    }
  }

  async logout() {
    try {
      await this.apiRequest('/auth/logout', 'POST')
      this.clearUser()
      this.showNotification('Logout successful!', 'success')
    } catch (error) {
      this.showNotification('Logout failed: ' + error.message, 'error')
    }
  }

  setUser(user) {
    this.user = user
    document.getElementById('userName').textContent = user.name || 'User'
    document.getElementById('userBalance').textContent = `Balance: ${user.balance || '0.00000000'} BTC`
    document.getElementById('mainBalance').textContent = user.balance || '0.00000000'
    document.getElementById('loginBtn').classList.add('hidden')
    document.getElementById('logoutBtn').classList.remove('hidden')
  }

  clearUser() {
    this.user = null
    document.getElementById('userName').textContent = 'Guest User'
    document.getElementById('userBalance').textContent = 'Balance: 0.00000000 BTC'
    document.getElementById('mainBalance').textContent = '0.00000000'
    document.getElementById('loginBtn').classList.remove('hidden')
    document.getElementById('logoutBtn').classList.add('hidden')
  }

  async loadPlatforms() {
    try {
      const response = await this.apiRequest('/platform/list', 'GET')
      if (response.success) {
        this.platforms = response.platforms
        this.updatePlatformsUI()
      }
    } catch (error) {
      console.error('Failed to load platforms:', error)
    }
  }

  updatePlatformsUI() {
    const container = document.getElementById('activePlatforms')
    if (this.platforms.length === 0) {
      container.innerHTML = '<div class="text-gray-500 text-sm">No platforms available</div>'
      return
    }

    container.innerHTML = this.platforms.map(platform => `
      <div class="flex items-center justify-between">
        <span class="text-sm font-medium">${platform.name}</span>
        <span class="status-indicator status-${platform.isActive === 'active' ? 'active' : 'inactive'}"></span>
      </div>
    `).join('')
  }

  async loadTransactionHistory() {
    if (!this.user) return

    try {
      const response = await this.apiRequest('/deposit/history?limit=10', 'GET')
      if (response.success) {
        this.transactions = response.transactions
        this.updateTransactionHistoryUI()
      }
    } catch (error) {
      console.error('Failed to load transaction history:', error)
    }
  }

  updateTransactionHistoryUI() {
    const tbody = document.getElementById('transactionHistory')
    if (this.transactions.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4" class="px-6 py-4 text-center text-gray-500">No transactions found</td></tr>'
      return
    }

    tbody.innerHTML = this.transactions.map(tx => `
      <tr>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${new Date(tx.createdAt).toLocaleDateString()}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-${tx.type === 'deposit' ? 'green' : 'blue'}-100 text-${tx.type === 'deposit' ? 'green' : 'blue'}-800">
            ${tx.type}
          </span>
        </td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${tx.amount} ${tx.currency}</td>
        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
          <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-${this.getStatusColor(tx.status)}-100 text-${this.getStatusColor(tx.status)}-800">
            ${tx.status}
          </span>
        </td>
      </tr>
    `).join('')
  }

  getStatusColor(status) {
    const colors = {
      pending: 'yellow',
      confirmed: 'green',
      failed: 'red',
      cancelled: 'gray'
    }
    return colors[status] || 'gray'
  }

  // Modal functions
  showDepositModal() {
    if (!this.user) {
      this.showNotification('Please login first', 'warning')
      return
    }
    document.getElementById('depositModal').classList.remove('hidden')
    document.getElementById('depositModal').classList.add('flex')
  }

  hideDepositModal() {
    document.getElementById('depositModal').classList.add('hidden')
    document.getElementById('depositModal').classList.remove('flex')
    document.getElementById('depositForm').reset()
  }

  showRedeemModal() {
    if (!this.user) {
      this.showNotification('Please login first', 'warning')
      return
    }
    document.getElementById('redeemModal').classList.remove('hidden')
    document.getElementById('redeemModal').classList.add('flex')
  }

  hideRedeemModal() {
    document.getElementById('redeemModal').classList.add('hidden')
    document.getElementById('redeemModal').classList.remove('flex')
    document.getElementById('redeemForm').reset()
  }

  showPlatformModal() {
    if (!this.user) {
      this.showNotification('Please login first', 'warning')
      return
    }
    this.updatePlatformSelect()
    document.getElementById('platformModal').classList.remove('hidden')
    document.getElementById('platformModal').classList.add('flex')
  }

  hidePlatformModal() {
    document.getElementById('platformModal').classList.add('hidden')
    document.getElementById('platformModal').classList.remove('flex')
    document.getElementById('platformForm').reset()
  }

  updatePlatformSelect() {
    const select = document.getElementById('platformSelect')
    select.innerHTML = '<option value="">Choose a platform...</option>' +
      this.platforms.map(platform => 
        `<option value="${platform.id}">${platform.name}</option>`
      ).join('')
  }

  // Form handlers
  async handleDeposit(e) {
    e.preventDefault()
    if (!this.user) return

    const amount = document.getElementById('depositAmount').value
    
    try {
      const response = await this.apiRequest('/deposit/initiate', 'POST', { amount })
      if (response.success) {
        this.showNotification('Deposit initiated! Check the invoice URL to complete payment.', 'success')
        this.hideDepositModal()
        // In a real app, you'd redirect to the checkout URL
        if (response.checkoutLink) {
          window.open(response.checkoutLink, '_blank')
        }
      }
    } catch (error) {
      this.showNotification('Deposit failed: ' + error.message, 'error')
    }
  }

  async handleRedeem(e) {
    e.preventDefault()
    if (!this.user) return

    const amount = document.getElementById('redeemAmount').value
    const walletAddress = document.getElementById('walletAddress').value
    
    try {
      const response = await this.apiRequest('/redeem/request', 'POST', { amount, walletAddress })
      if (response.success) {
        this.showNotification('Withdrawal request submitted!', 'success')
        this.setUser({ ...this.user, balance: response.newBalance })
        this.hideRedeemModal()
      }
    } catch (error) {
      this.showNotification('Redeem failed: ' + error.message, 'error')
    }
  }

  async handlePlatformRequest(e) {
    e.preventDefault()
    if (!this.user) return

    const platformId = parseInt(document.getElementById('platformSelect').value)
    
    try {
      const response = await this.apiRequest('/platform/getAccount', 'POST', { platformId })
      if (response.success) {
        this.showNotification('Platform account request submitted! You will be notified when ready.', 'success')
        this.hidePlatformModal()
      }
    } catch (error) {
      this.showNotification('Platform request failed: ' + error.message, 'error')
    }
  }

  // API helper
  async apiRequest(endpoint, method = 'GET', data = null) {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include' // Include cookies for auth
    }

    if (data) {
      options.body = JSON.stringify(data)
    }

    const response = await fetch(`${this.apiBase}${endpoint}`, options)
    const result = await response.json()

    if (!response.ok) {
      throw new Error(result.error || 'Request failed')
    }

    return result
  }

  // Utility functions
  showNotification(message, type = 'info') {
    const colors = {
      success: 'bg-green-500',
      error: 'bg-red-500',
      warning: 'bg-yellow-500',
      info: 'bg-blue-500'
    }

    const notification = document.createElement('div')
    notification.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 transform transition-all duration-300`
    notification.innerHTML = `
      <div class="flex items-center">
        <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : type === 'warning' ? 'exclamation' : 'info'} mr-2"></i>
        <span>${message}</span>
      </div>
    `

    document.body.appendChild(notification)

    setTimeout(() => {
      notification.style.opacity = '0'
      setTimeout(() => notification.remove(), 300)
    }, 3000)
  }

  refreshData() {
    this.loadTransactionHistory()
    this.showNotification('Data refreshed!', 'success')
  }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
  window.app = new CryptoPlatformManager()
})